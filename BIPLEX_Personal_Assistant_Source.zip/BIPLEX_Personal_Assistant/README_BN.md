# BIPLEX Personal Assistant — Android APK

এটি একটি Flutter + Kotlin Android অ্যাপের GitHub-ready source project।

## কীভাবে ব্যবহার করবে

1. ZIP extract করে `BIPLEX_Personal_Assistant` ফোল্ডারের ভেতরের সব ফাইল GitHub repository-র root-এ upload/push করো।
2. Repository-এর default branch `main` রাখো।
3. GitHub → Actions → **BIPLEX Personal Assistant APK** → **Run workflow** চাপো।
4. Build সফল হলে workflow run-এর Artifacts থেকে `BIPLEX-Personal-Assistant-APK` ZIP ডাউনলোড করো।
5. ZIP extract করে `app-release.apk` ইনস্টল করো।

## প্রথমবার চালু করার পর

1. অ্যাপ খুলে **ACTIVATE VOICE ASSISTANT** চাপো।
2. Android Exact Alarm permission চাইলে Allow করো।
3. Permission দিয়ে ফিরে এসে আবার Voice Assistant বাটনে চাপো।
4. Media volume বাড়াও।
5. ফোনের Text-to-Speech/Speech Services-এ বাংলা voice data আছে কি না যাচাই করো।
6. প্রথমে কাছাকাছি সময়ের একটি test reminder যোগ করে পরীক্ষা করো।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- Android-এর Force Stop করলে অ্যালার্ম চলবে না; অ্যাপ আবার খুলে Voice Assistant চালু করতে হবে।
- কিছু Realme ফোনে Battery settings থেকে background restriction বন্ধ/অনুমতি দিতে হতে পারে।
- বাংলা কণ্ঠ ও উচ্চারণ ফোনের TTS engine এবং ইনস্টল করা voice data-এর ওপর নির্ভরশীল।
- ফোন সম্পূর্ণ বন্ধ থাকলে কোনো অ্যাপই নির্ধারিত সময়ে কথা বলতে পারবে না।
- Default routine-এ পর্যাপ্ত ঘুম, খাবার ও বিরতি রাখা হয়েছে। প্রয়োজনমতো অ্যাপের ভেতর থেকে সময় ও বার্তা সম্পাদনা করা যাবে।

## Project layout

- `lib/main.dart` — Flutter UI, routine editor, local storage
- `native/` — Android Manifest এবং Kotlin alarm/voice services
- `.github/workflows/build.yml` — GitHub Actions APK build

এই repository-তে Android Gradle project ইচ্ছাকৃতভাবে আগে থেকে রাখা হয়নি। GitHub Actions Flutter দিয়ে সেটি তৈরি করে তারপর Native Kotlin files বসায়।
