package com.biplob.biplex_assistant

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channel = "com.biplob.biplex/alarms"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channel
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "scheduleAll" -> {
                    val json = call.argument<String>("json")
                    if (json == null) {
                        result.error("INVALID_DATA", "Routine data missing", null)
                        return@setMethodCallHandler
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        val manager = getSystemService(
                            Context.ALARM_SERVICE
                        ) as AlarmManager

                        if (!manager.canScheduleExactAlarms()) {
                            val settingsIntent = Intent(
                                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(settingsIntent)
                            result.success(false)
                            return@setMethodCallHandler
                        }
                    }

                    AlarmScheduler.scheduleAll(this, json)
                    result.success(true)
                }

                "cancelAll" -> {
                    AlarmScheduler.cancelAll(this)
                    result.success(true)
                }

                else -> result.notImplemented()
            }
        }
    }
}
