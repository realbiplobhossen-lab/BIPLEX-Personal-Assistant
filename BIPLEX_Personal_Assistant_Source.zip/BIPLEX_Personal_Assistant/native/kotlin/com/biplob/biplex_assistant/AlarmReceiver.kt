package com.biplob.biplex_assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val title = intent.getStringExtra("title") ?: "BIPLEX Reminder"
        val message = intent.getStringExtra("message") ?: ""
        val hour = intent.getIntExtra("hour", 0)
        val minute = intent.getIntExtra("minute", 0)

        // Schedule tomorrow's reminder before starting speech.
        AlarmScheduler.scheduleNext(context, id, title, message, hour, minute)

        val serviceIntent = Intent(context, VoiceAlarmService::class.java).apply {
            putExtra("title", title)
            putExtra("message", message)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {
            // Android may block background service starts in restricted states.
        }
    }
}
