package com.biplob.biplex_assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {
    private const val PREFS = "biplex_alarm_data"
    private const val KEY_ROUTINES = "routines"

    fun scheduleAll(context: Context, json: String) {
        cancelAll(context)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ROUTINES, json)
            .apply()

        val array = org.json.JSONArray(json)
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            scheduleNext(
                context,
                item.getString("id"),
                item.getString("title"),
                item.getString("message"),
                item.getInt("hour"),
                item.getInt("minute")
            )
        }
    }

    fun scheduleNext(
        context: Context,
        id: String,
        title: String,
        message: String,
        hour: Int,
        minute: Int
    ) {
        val manager = context.getSystemService(
            Context.ALARM_SERVICE
        ) as AlarmManager

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("id", id)
            putExtra("title", title)
            putExtra("message", message)
            putExtra("hour", hour)
            putExtra("minute", minute)
        }

        val requestCode = id.hashCode()
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode,
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = Intent(context, MainActivity::class.java)
        val showPending = PendingIntent.getActivity(
            context,
            requestCode + 1,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        manager.setAlarmClock(
            AlarmManager.AlarmClockInfo(calendar.timeInMillis, showPending),
            pending
        )
    }

    fun cancelAll(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_ROUTINES, null) ?: return
        val array = org.json.JSONArray(json)
        val manager = context.getSystemService(
            Context.ALARM_SERVICE
        ) as AlarmManager

        for (i in 0 until array.length()) {
            val id = array.getJSONObject(i).getString("id")
            val pending = PendingIntent.getBroadcast(
                context,
                id.hashCode(),
                Intent(context, AlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            manager.cancel(pending)
            pending.cancel()
        }
    }

    fun restore(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_ROUTINES, null) ?: return
        scheduleAll(context, json)
    }
}
